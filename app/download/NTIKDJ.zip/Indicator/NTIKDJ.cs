#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
#endregion

// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    /// <summary>
    /// KDJ Indicator by NT Indicators
    /// </summary>
    [Description("KDJ Indicator by NT Indicators")]
    public class NTIKDJ : Indicator
    {
        #region Variables
        // Wizard generated variables
            private int periodK = 14; // Default setting for PeriodK
            private int periodD = 3; // Default setting for PeriodD
            private int periodJ = 3; // Default setting for PeriodJ
        // User defined variables (add any user defined variables below)
			private DataSeries			den;
			private DataSeries			nom;
        #endregion

        /// <summary>
        /// This method is used to configure the indicator and is called once before any bar data is loaded.
        /// </summary>
        protected override void Initialize()
        {
            Add(new Plot(Color.FromKnownColor(KnownColor.Orange), PlotStyle.Line, "KLine"));
            Add(new Plot(Color.FromKnownColor(KnownColor.Green), PlotStyle.Line, "DLine"));
            Add(new Plot(Color.FromKnownColor(KnownColor.Red), PlotStyle.Line, "JLine"));
            Add(new Line(Color.FromKnownColor(KnownColor.DarkViolet), 20, "Lower"));
            Add(new Line(Color.FromKnownColor(KnownColor.YellowGreen), 80, "Upper"));
            Overlay				= false;
			
			den = new DataSeries(this);
			nom = new DataSeries(this);
			
		}

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
            // Use this method for calculating your indicator values. Assign a value to each
            // plot below by replacing 'Close[0]' with your own formula.
            nom.Set(Close[0] - MIN(Low, PeriodK)[0]);
            den.Set(MAX(High, PeriodK)[0] - MIN(Low, PeriodK)[0]);

            if (den[0].Compare(0, 0.000000000001) == 0)
                KLine.Set(CurrentBar == 0 ? 50 : KLine[1]);
            else
                KLine.Set(Math.Min(100, Math.Max(0, 100 * nom[0] / den[0])));

            DLine.Set(SMA(KLine, PeriodD)[0]);
			JLine.Set(PeriodJ * KLine[0] - (PeriodJ-1) * DLine[0]);

        }

        #region Properties
        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries KLine
        {
            get { return Values[0]; }
        }

        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries DLine
        {
            get { return Values[1]; }
        }

        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries JLine
        {
            get { return Values[2]; }
        }

        [Description("Period of K")]
        [GridCategory("Parameters")]
        public int PeriodK
        {
            get { return periodK; }
            set { periodK = Math.Max(1, value); }
        }

        [Description("Period of D")]
        [GridCategory("Parameters")]
        public int PeriodD
        {
            get { return periodD; }
            set { periodD = Math.Max(1, value); }
        }

        [Description("Period of J")]
        [GridCategory("Parameters")]
        public int PeriodJ
        {
            get { return periodJ; }
            set { periodJ = Math.Max(1, value); }
        }
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.
// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    public partial class Indicator : IndicatorBase
    {
        private NTIKDJ[] cacheNTIKDJ = null;

        private static NTIKDJ checkNTIKDJ = new NTIKDJ();

        /// <summary>
        /// KDJ Indicator by NT Indicators
        /// </summary>
        /// <returns></returns>
        public NTIKDJ NTIKDJ(int periodD, int periodJ, int periodK)
        {
            return NTIKDJ(Input, periodD, periodJ, periodK);
        }

        /// <summary>
        /// KDJ Indicator by NT Indicators
        /// </summary>
        /// <returns></returns>
        public NTIKDJ NTIKDJ(Data.IDataSeries input, int periodD, int periodJ, int periodK)
        {
            if (cacheNTIKDJ != null)
                for (int idx = 0; idx < cacheNTIKDJ.Length; idx++)
                    if (cacheNTIKDJ[idx].PeriodD == periodD && cacheNTIKDJ[idx].PeriodJ == periodJ && cacheNTIKDJ[idx].PeriodK == periodK && cacheNTIKDJ[idx].EqualsInput(input))
                        return cacheNTIKDJ[idx];

            lock (checkNTIKDJ)
            {
                checkNTIKDJ.PeriodD = periodD;
                periodD = checkNTIKDJ.PeriodD;
                checkNTIKDJ.PeriodJ = periodJ;
                periodJ = checkNTIKDJ.PeriodJ;
                checkNTIKDJ.PeriodK = periodK;
                periodK = checkNTIKDJ.PeriodK;

                if (cacheNTIKDJ != null)
                    for (int idx = 0; idx < cacheNTIKDJ.Length; idx++)
                        if (cacheNTIKDJ[idx].PeriodD == periodD && cacheNTIKDJ[idx].PeriodJ == periodJ && cacheNTIKDJ[idx].PeriodK == periodK && cacheNTIKDJ[idx].EqualsInput(input))
                            return cacheNTIKDJ[idx];

                NTIKDJ indicator = new NTIKDJ();
                indicator.BarsRequired = BarsRequired;
                indicator.CalculateOnBarClose = CalculateOnBarClose;
#if NT7
                indicator.ForceMaximumBarsLookBack256 = ForceMaximumBarsLookBack256;
                indicator.MaximumBarsLookBack = MaximumBarsLookBack;
#endif
                indicator.Input = input;
                indicator.PeriodD = periodD;
                indicator.PeriodJ = periodJ;
                indicator.PeriodK = periodK;
                Indicators.Add(indicator);
                indicator.SetUp();

                NTIKDJ[] tmp = new NTIKDJ[cacheNTIKDJ == null ? 1 : cacheNTIKDJ.Length + 1];
                if (cacheNTIKDJ != null)
                    cacheNTIKDJ.CopyTo(tmp, 0);
                tmp[tmp.Length - 1] = indicator;
                cacheNTIKDJ = tmp;
                return indicator;
            }
        }
    }
}

// This namespace holds all market analyzer column definitions and is required. Do not change it.
namespace NinjaTrader.MarketAnalyzer
{
    public partial class Column : ColumnBase
    {
        /// <summary>
        /// KDJ Indicator by NT Indicators
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.NTIKDJ NTIKDJ(int periodD, int periodJ, int periodK)
        {
            return _indicator.NTIKDJ(Input, periodD, periodJ, periodK);
        }

        /// <summary>
        /// KDJ Indicator by NT Indicators
        /// </summary>
        /// <returns></returns>
        public Indicator.NTIKDJ NTIKDJ(Data.IDataSeries input, int periodD, int periodJ, int periodK)
        {
            return _indicator.NTIKDJ(input, periodD, periodJ, periodK);
        }
    }
}

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    public partial class Strategy : StrategyBase
    {
        /// <summary>
        /// KDJ Indicator by NT Indicators
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.NTIKDJ NTIKDJ(int periodD, int periodJ, int periodK)
        {
            return _indicator.NTIKDJ(Input, periodD, periodJ, periodK);
        }

        /// <summary>
        /// KDJ Indicator by NT Indicators
        /// </summary>
        /// <returns></returns>
        public Indicator.NTIKDJ NTIKDJ(Data.IDataSeries input, int periodD, int periodJ, int periodK)
        {
            if (InInitialize && input == null)
                throw new ArgumentException("You only can access an indicator with the default input/bar series from within the 'Initialize()' method");

            return _indicator.NTIKDJ(input, periodD, periodJ, periodK);
        }
    }
}
#endregion
