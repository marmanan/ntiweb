#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
#endregion

// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    /// <summary>
    /// Coppock Curve by NT Indicators. Long trend following indicator
    /// </summary>
    [Description("Coppock Curve by NT Indicators. Long trend following indicator")]
    public class NTICoppockCurve : Indicator
    {
        #region Variables
        // Wizard generated variables
            private int a = 14; // Default setting for A
            private int b = 11; // Default setting for B
            private int c = 10; // Default setting for C
        // User defined variables (add any user defined variables below)
			private DataSeries coppock;
        #endregion

        /// <summary>
        /// This method is used to configure the indicator and is called once before any bar data is loaded.
        /// </summary>
        protected override void Initialize()
        {
            Add(new Plot(Color.FromKnownColor(KnownColor.Green), PlotStyle.Line, "CoppockLine"));
			Add(new Line(Color.Gray, 0, "Zero"));
			coppock = new DataSeries(this);
            Overlay				= false;
        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
			double rocA = ROC(Close,a)[0];
			double rocB = ROC(Close,b)[0];
			coppock.Set(rocA+rocB);
			double coppockValue = WMA(coppock,c)[0];
            CopporckLine.Set(coppockValue);
        }

        #region Properties
        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries CopporckLine
        {
            get { return Values[0]; }
        }

        [Description("A period")]
        [GridCategory("Parameters")]
        public int A
        {
            get { return a; }
            set { a = Math.Max(1, value); }
        }

        [Description("B period")]
        [GridCategory("Parameters")]
        public int B
        {
            get { return b; }
            set { b = Math.Max(1, value); }
        }

        [Description("C period")]
        [GridCategory("Parameters")]
        public int C
        {
            get { return c; }
            set { c = Math.Max(1, value); }
        }
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.
// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    public partial class Indicator : IndicatorBase
    {
        private NTICoppockCurve[] cacheNTICoppockCurve = null;

        private static NTICoppockCurve checkNTICoppockCurve = new NTICoppockCurve();

        /// <summary>
        /// Coppock Curve by NT Indicators. Long trend following indicator
        /// </summary>
        /// <returns></returns>
        public NTICoppockCurve NTICoppockCurve(int a, int b, int c)
        {
            return NTICoppockCurve(Input, a, b, c);
        }

        /// <summary>
        /// Coppock Curve by NT Indicators. Long trend following indicator
        /// </summary>
        /// <returns></returns>
        public NTICoppockCurve NTICoppockCurve(Data.IDataSeries input, int a, int b, int c)
        {
            if (cacheNTICoppockCurve != null)
                for (int idx = 0; idx < cacheNTICoppockCurve.Length; idx++)
                    if (cacheNTICoppockCurve[idx].A == a && cacheNTICoppockCurve[idx].B == b && cacheNTICoppockCurve[idx].C == c && cacheNTICoppockCurve[idx].EqualsInput(input))
                        return cacheNTICoppockCurve[idx];

            lock (checkNTICoppockCurve)
            {
                checkNTICoppockCurve.A = a;
                a = checkNTICoppockCurve.A;
                checkNTICoppockCurve.B = b;
                b = checkNTICoppockCurve.B;
                checkNTICoppockCurve.C = c;
                c = checkNTICoppockCurve.C;

                if (cacheNTICoppockCurve != null)
                    for (int idx = 0; idx < cacheNTICoppockCurve.Length; idx++)
                        if (cacheNTICoppockCurve[idx].A == a && cacheNTICoppockCurve[idx].B == b && cacheNTICoppockCurve[idx].C == c && cacheNTICoppockCurve[idx].EqualsInput(input))
                            return cacheNTICoppockCurve[idx];

                NTICoppockCurve indicator = new NTICoppockCurve();
                indicator.BarsRequired = BarsRequired;
                indicator.CalculateOnBarClose = CalculateOnBarClose;
#if NT7
                indicator.ForceMaximumBarsLookBack256 = ForceMaximumBarsLookBack256;
                indicator.MaximumBarsLookBack = MaximumBarsLookBack;
#endif
                indicator.Input = input;
                indicator.A = a;
                indicator.B = b;
                indicator.C = c;
                Indicators.Add(indicator);
                indicator.SetUp();

                NTICoppockCurve[] tmp = new NTICoppockCurve[cacheNTICoppockCurve == null ? 1 : cacheNTICoppockCurve.Length + 1];
                if (cacheNTICoppockCurve != null)
                    cacheNTICoppockCurve.CopyTo(tmp, 0);
                tmp[tmp.Length - 1] = indicator;
                cacheNTICoppockCurve = tmp;
                return indicator;
            }
        }
    }
}

// This namespace holds all market analyzer column definitions and is required. Do not change it.
namespace NinjaTrader.MarketAnalyzer
{
    public partial class Column : ColumnBase
    {
        /// <summary>
        /// Coppock Curve by NT Indicators. Long trend following indicator
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.NTICoppockCurve NTICoppockCurve(int a, int b, int c)
        {
            return _indicator.NTICoppockCurve(Input, a, b, c);
        }

        /// <summary>
        /// Coppock Curve by NT Indicators. Long trend following indicator
        /// </summary>
        /// <returns></returns>
        public Indicator.NTICoppockCurve NTICoppockCurve(Data.IDataSeries input, int a, int b, int c)
        {
            return _indicator.NTICoppockCurve(input, a, b, c);
        }
    }
}

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    public partial class Strategy : StrategyBase
    {
        /// <summary>
        /// Coppock Curve by NT Indicators. Long trend following indicator
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.NTICoppockCurve NTICoppockCurve(int a, int b, int c)
        {
            return _indicator.NTICoppockCurve(Input, a, b, c);
        }

        /// <summary>
        /// Coppock Curve by NT Indicators. Long trend following indicator
        /// </summary>
        /// <returns></returns>
        public Indicator.NTICoppockCurve NTICoppockCurve(Data.IDataSeries input, int a, int b, int c)
        {
            if (InInitialize && input == null)
                throw new ArgumentException("You only can access an indicator with the default input/bar series from within the 'Initialize()' method");

            return _indicator.NTICoppockCurve(input, a, b, c);
        }
    }
}
#endregion
