#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
#endregion

namespace NinjaTrader.Indicator
{
    /// <summary>
    /// Moving Average Confluence
    /// </summary>
    [Description("Moving Average Confluence")]
    public class NTIMovingAverageConfluence : Indicator
    {
        #region Variables
        #endregion

        /// <summary>
        /// This method is used to configure the indicator and is called once before any bar data is loaded.
        /// </summary>
        protected override void Initialize()
        {
            Add(new Plot(Color.FromKnownColor(KnownColor.Red), PlotStyle.Line, "Moving Average Confluence"));
			Add(new Line(Color.FromKnownColor(KnownColor.Red), 20, "Lower"));
            Add(new Line(Color.FromKnownColor(KnownColor.YellowGreen), 80, "Upper"));
			
			Overlay				= false;
        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
            double movAverage = 0;
			
			double mm1 = SMA(Close,1)[0];
			double mm2 = SMA(Close,2)[0];
			double mm3 = SMA(Close,3)[0];
			double mm4 = SMA(Close,4)[0];
			double mm5 = SMA(Close,5)[0];
			double mm6 = SMA(Close,6)[0];
			double mm7 = SMA(Close,7)[0];
			double mm8 = SMA(Close,8)[0];
			double mm9 = SMA(Close,9)[0];
			double mm10 = SMA(Close,10)[0];
			double mm11 = SMA(Close,11)[0];
			double mm12 = SMA(Close,12)[0];
			double mm13 = SMA(Close,13)[0];
			double mm14 = SMA(Close,14)[0];
			double mm15 = SMA(Close,15)[0];
			double mm16 = SMA(Close,16)[0];
			double mm17 = SMA(Close,17)[0];
			double mm18 = SMA(Close,18)[0];
			double mm19 = SMA(Close,19)[0];
			double mm20 = SMA(Close,20)[0];
			double mm24 = SMA(Close,24)[0];
			double mm28 = SMA(Close,28)[0];
			double mm32 = SMA(Close,32)[0];
			double mm36 = SMA(Close,36)[0];
			double mm40 = SMA(Close,40)[0];
			double mm44 = SMA(Close,44)[0];
			double mm48 = SMA(Close,48)[0];
			double mm52 = SMA(Close,52)[0];
			double mm56 = SMA(Close,56)[0];
			double mm60 = SMA(Close,60)[0];
			double mm64 = SMA(Close,64)[0];
			double mm68 = SMA(Close,68)[0];
			double mm72 = SMA(Close,72)[0];
			double mm76 = SMA(Close,76)[0];
			double mm80 = SMA(Close,80)[0];

			if (mm1>mm4) movAverage+=5;
			if (mm2>mm8) movAverage+=5;
			if (mm3>mm12) movAverage+=5;
			if (mm4>mm16) movAverage+=5;
			if (mm5>mm20) movAverage+=5;
			if (mm6>mm24) movAverage+=5;
			if (mm7>mm28) movAverage+=5;
			if (mm8>mm32) movAverage+=5;
			if (mm9>mm36) movAverage+=5;
			if (mm10>mm40) movAverage+=5;
			if (mm11>mm44) movAverage+=5;
			if (mm12>mm48) movAverage+=5;
			if (mm13>mm52) movAverage+=5;
			if (mm14>mm56) movAverage+=5;
			if (mm15>mm60) movAverage+=5;
			if (mm16>mm64) movAverage+=5;
			if (mm17>mm68) movAverage+=5;
			if (mm18>mm72) movAverage+=5;
			if (mm19>mm76) movAverage+=5;
			if (mm20>mm80) movAverage+=5;
			
			
            MovingAverageConfluence.Set(movAverage);
        }

        #region Properties
        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries MovingAverageConfluence
        {
            get { return Values[0]; }
        }

        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.
// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    public partial class Indicator : IndicatorBase
    {
        private NTIMovingAverageConfluence[] cacheNTIMovingAverageConfluence = null;

        private static NTIMovingAverageConfluence checkNTIMovingAverageConfluence = new NTIMovingAverageConfluence();

        /// <summary>
        /// Moving Average Confluence
        /// </summary>
        /// <returns></returns>
        public NTIMovingAverageConfluence NTIMovingAverageConfluence()
        {
            return NTIMovingAverageConfluence(Input);
        }

        /// <summary>
        /// Moving Average Confluence
        /// </summary>
        /// <returns></returns>
        public NTIMovingAverageConfluence NTIMovingAverageConfluence(Data.IDataSeries input)
        {
            if (cacheNTIMovingAverageConfluence != null)
                for (int idx = 0; idx < cacheNTIMovingAverageConfluence.Length; idx++)
                    if (cacheNTIMovingAverageConfluence[idx].EqualsInput(input))
                        return cacheNTIMovingAverageConfluence[idx];

            lock (checkNTIMovingAverageConfluence)
            {
                if (cacheNTIMovingAverageConfluence != null)
                    for (int idx = 0; idx < cacheNTIMovingAverageConfluence.Length; idx++)
                        if (cacheNTIMovingAverageConfluence[idx].EqualsInput(input))
                            return cacheNTIMovingAverageConfluence[idx];

                NTIMovingAverageConfluence indicator = new NTIMovingAverageConfluence();
                indicator.BarsRequired = BarsRequired;
                indicator.CalculateOnBarClose = CalculateOnBarClose;
#if NT7
                indicator.ForceMaximumBarsLookBack256 = ForceMaximumBarsLookBack256;
                indicator.MaximumBarsLookBack = MaximumBarsLookBack;
#endif
                indicator.Input = input;
                Indicators.Add(indicator);
                indicator.SetUp();

                NTIMovingAverageConfluence[] tmp = new NTIMovingAverageConfluence[cacheNTIMovingAverageConfluence == null ? 1 : cacheNTIMovingAverageConfluence.Length + 1];
                if (cacheNTIMovingAverageConfluence != null)
                    cacheNTIMovingAverageConfluence.CopyTo(tmp, 0);
                tmp[tmp.Length - 1] = indicator;
                cacheNTIMovingAverageConfluence = tmp;
                return indicator;
            }
        }
    }
}

// This namespace holds all market analyzer column definitions and is required. Do not change it.
namespace NinjaTrader.MarketAnalyzer
{
    public partial class Column : ColumnBase
    {
        /// <summary>
        /// Moving Average Confluence
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.NTIMovingAverageConfluence NTIMovingAverageConfluence()
        {
            return _indicator.NTIMovingAverageConfluence(Input);
        }

        /// <summary>
        /// Moving Average Confluence
        /// </summary>
        /// <returns></returns>
        public Indicator.NTIMovingAverageConfluence NTIMovingAverageConfluence(Data.IDataSeries input)
        {
            return _indicator.NTIMovingAverageConfluence(input);
        }
    }
}

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    public partial class Strategy : StrategyBase
    {
        /// <summary>
        /// Moving Average Confluence
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.NTIMovingAverageConfluence NTIMovingAverageConfluence()
        {
            return _indicator.NTIMovingAverageConfluence(Input);
        }

        /// <summary>
        /// Moving Average Confluence
        /// </summary>
        /// <returns></returns>
        public Indicator.NTIMovingAverageConfluence NTIMovingAverageConfluence(Data.IDataSeries input)
        {
            if (InInitialize && input == null)
                throw new ArgumentException("You only can access an indicator with the default input/bar series from within the 'Initialize()' method");

            return _indicator.NTIMovingAverageConfluence(input);
        }
    }
}
#endregion
