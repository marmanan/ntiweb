#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
#endregion

// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    /// <summary>
    /// The Force Index is an indicator that uses price and volume to assess the power behind a move or identify possible turning points.
    /// </summary>
    [Description("The Force Index is an indicator that uses price and volume to assess the power behind a move or identify possible turning points.")]
    public class NTIForceIndex : Indicator
    {
        #region Variables
        // Wizard generated variables
            private int period = 13; // Default setting for Period
        // User defined variables (add any user defined variables below)
			private DataSeries forceIndexSerie;
        #endregion

        /// <summary>
        /// This method is used to configure the indicator and is called once before any bar data is loaded.
        /// </summary>
        protected override void Initialize()
        {
            Add(new Plot(Color.FromKnownColor(KnownColor.Black), PlotStyle.Line, "ForceIndex"));
			forceIndexSerie = new DataSeries(this);
            Overlay				= false;
        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
            if (CurrentBar>0)
			{
				forceIndexSerie.Set((Close[0]-Close[1])*Volume[0]);
				double fi = EMA(forceIndexSerie,period)[0];
            	ForceIndex.Set(fi);
			}
        }

        #region Properties
        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries ForceIndex
        {
            get { return Values[0]; }
        }

        [Description("Oscillator period")]
        [GridCategory("Parameters")]
        public int Period
        {
            get { return period; }
            set { period = Math.Max(1, value); }
        }
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.
// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    public partial class Indicator : IndicatorBase
    {
        private NTIForceIndex[] cacheNTIForceIndex = null;

        private static NTIForceIndex checkNTIForceIndex = new NTIForceIndex();

        /// <summary>
        /// The Force Index is an indicator that uses price and volume to assess the power behind a move or identify possible turning points.
        /// </summary>
        /// <returns></returns>
        public NTIForceIndex NTIForceIndex(int period)
        {
            return NTIForceIndex(Input, period);
        }

        /// <summary>
        /// The Force Index is an indicator that uses price and volume to assess the power behind a move or identify possible turning points.
        /// </summary>
        /// <returns></returns>
        public NTIForceIndex NTIForceIndex(Data.IDataSeries input, int period)
        {
            if (cacheNTIForceIndex != null)
                for (int idx = 0; idx < cacheNTIForceIndex.Length; idx++)
                    if (cacheNTIForceIndex[idx].Period == period && cacheNTIForceIndex[idx].EqualsInput(input))
                        return cacheNTIForceIndex[idx];

            lock (checkNTIForceIndex)
            {
                checkNTIForceIndex.Period = period;
                period = checkNTIForceIndex.Period;

                if (cacheNTIForceIndex != null)
                    for (int idx = 0; idx < cacheNTIForceIndex.Length; idx++)
                        if (cacheNTIForceIndex[idx].Period == period && cacheNTIForceIndex[idx].EqualsInput(input))
                            return cacheNTIForceIndex[idx];

                NTIForceIndex indicator = new NTIForceIndex();
                indicator.BarsRequired = BarsRequired;
                indicator.CalculateOnBarClose = CalculateOnBarClose;
#if NT7
                indicator.ForceMaximumBarsLookBack256 = ForceMaximumBarsLookBack256;
                indicator.MaximumBarsLookBack = MaximumBarsLookBack;
#endif
                indicator.Input = input;
                indicator.Period = period;
                Indicators.Add(indicator);
                indicator.SetUp();

                NTIForceIndex[] tmp = new NTIForceIndex[cacheNTIForceIndex == null ? 1 : cacheNTIForceIndex.Length + 1];
                if (cacheNTIForceIndex != null)
                    cacheNTIForceIndex.CopyTo(tmp, 0);
                tmp[tmp.Length - 1] = indicator;
                cacheNTIForceIndex = tmp;
                return indicator;
            }
        }
    }
}

// This namespace holds all market analyzer column definitions and is required. Do not change it.
namespace NinjaTrader.MarketAnalyzer
{
    public partial class Column : ColumnBase
    {
        /// <summary>
        /// The Force Index is an indicator that uses price and volume to assess the power behind a move or identify possible turning points.
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.NTIForceIndex NTIForceIndex(int period)
        {
            return _indicator.NTIForceIndex(Input, period);
        }

        /// <summary>
        /// The Force Index is an indicator that uses price and volume to assess the power behind a move or identify possible turning points.
        /// </summary>
        /// <returns></returns>
        public Indicator.NTIForceIndex NTIForceIndex(Data.IDataSeries input, int period)
        {
            return _indicator.NTIForceIndex(input, period);
        }
    }
}

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    public partial class Strategy : StrategyBase
    {
        /// <summary>
        /// The Force Index is an indicator that uses price and volume to assess the power behind a move or identify possible turning points.
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.NTIForceIndex NTIForceIndex(int period)
        {
            return _indicator.NTIForceIndex(Input, period);
        }

        /// <summary>
        /// The Force Index is an indicator that uses price and volume to assess the power behind a move or identify possible turning points.
        /// </summary>
        /// <returns></returns>
        public Indicator.NTIForceIndex NTIForceIndex(Data.IDataSeries input, int period)
        {
            if (InInitialize && input == null)
                throw new ArgumentException("You only can access an indicator with the default input/bar series from within the 'Initialize()' method");

            return _indicator.NTIForceIndex(input, period);
        }
    }
}
#endregion
