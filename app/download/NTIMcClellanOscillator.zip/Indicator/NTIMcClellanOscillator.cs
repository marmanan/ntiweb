#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
#endregion

// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    /// <summary>
    /// McMellan Oscillator for advancing and declining stocks
    /// </summary>
    [Description("McMellan Oscillator for advancing and declining stocks")]
    public class NTIMcClellanOscillator : Indicator
    {
        #region Variables
        // Wizard generated variables
            private int slowPeriod = 39; // Default setting for SlowPeriod
            private int fastPeriod = 19; // Default setting for FastPeriod
			private DataSeries myDataSeries;
		
        // User defined variables (add any user defined variables below)
        #endregion

        /// <summary>
        /// This method is used to configure the indicator and is called once before any bar data is loaded.
        /// </summary>
        protected override void Initialize()
        {
			
            Add(new Plot(Color.FromKnownColor(KnownColor.Green), PlotStyle.Line, "McClellan"));
			Add(new Line(Color.FromKnownColor(KnownColor.DarkGray), 0, "Zero"));
			Add("^ADD", BarsPeriod.Id, BarsPeriod.Value);
			myDataSeries = new DataSeries(this);
            Overlay				= false;
			CalculateOnBarClose = true;
        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
			if (BarsInProgress == 0)
			{
						double McMellanUpperValue = 0;
						double McMellanLowerValue = 0;
						myDataSeries.Set(BarsArray[1][0]);
						double emaDiff = ((EMA(myDataSeries,fastPeriod)[0])-(EMA(myDataSeries,slowPeriod)[0]));

						McClellan.Set(emaDiff);
			}
        }

        #region Properties
        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries McClellan
        {
            get { return Values[0]; }
        }

        [Description("")]
        [GridCategory("Parameters")]
        public int SlowPeriod
        {
            get { return slowPeriod; }
            set { slowPeriod = Math.Max(1, value); }
        }

        [Description("")]
        [GridCategory("Parameters")]
        public int FastPeriod
        {
            get { return fastPeriod; }
            set { fastPeriod = Math.Max(1, value); }
        }
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.
// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    public partial class Indicator : IndicatorBase
    {
        private NTIMcClellanOscillator[] cacheNTIMcClellanOscillator = null;

        private static NTIMcClellanOscillator checkNTIMcClellanOscillator = new NTIMcClellanOscillator();

        /// <summary>
        /// McMellan Oscillator for advancing and declining stocks
        /// </summary>
        /// <returns></returns>
        public NTIMcClellanOscillator NTIMcClellanOscillator(int fastPeriod, int slowPeriod)
        {
            return NTIMcClellanOscillator(Input, fastPeriod, slowPeriod);
        }

        /// <summary>
        /// McMellan Oscillator for advancing and declining stocks
        /// </summary>
        /// <returns></returns>
        public NTIMcClellanOscillator NTIMcClellanOscillator(Data.IDataSeries input, int fastPeriod, int slowPeriod)
        {
            if (cacheNTIMcClellanOscillator != null)
                for (int idx = 0; idx < cacheNTIMcClellanOscillator.Length; idx++)
                    if (cacheNTIMcClellanOscillator[idx].FastPeriod == fastPeriod && cacheNTIMcClellanOscillator[idx].SlowPeriod == slowPeriod && cacheNTIMcClellanOscillator[idx].EqualsInput(input))
                        return cacheNTIMcClellanOscillator[idx];

            lock (checkNTIMcClellanOscillator)
            {
                checkNTIMcClellanOscillator.FastPeriod = fastPeriod;
                fastPeriod = checkNTIMcClellanOscillator.FastPeriod;
                checkNTIMcClellanOscillator.SlowPeriod = slowPeriod;
                slowPeriod = checkNTIMcClellanOscillator.SlowPeriod;

                if (cacheNTIMcClellanOscillator != null)
                    for (int idx = 0; idx < cacheNTIMcClellanOscillator.Length; idx++)
                        if (cacheNTIMcClellanOscillator[idx].FastPeriod == fastPeriod && cacheNTIMcClellanOscillator[idx].SlowPeriod == slowPeriod && cacheNTIMcClellanOscillator[idx].EqualsInput(input))
                            return cacheNTIMcClellanOscillator[idx];

                NTIMcClellanOscillator indicator = new NTIMcClellanOscillator();
                indicator.BarsRequired = BarsRequired;
                indicator.CalculateOnBarClose = CalculateOnBarClose;
#if NT7
                indicator.ForceMaximumBarsLookBack256 = ForceMaximumBarsLookBack256;
                indicator.MaximumBarsLookBack = MaximumBarsLookBack;
#endif
                indicator.Input = input;
                indicator.FastPeriod = fastPeriod;
                indicator.SlowPeriod = slowPeriod;
                Indicators.Add(indicator);
                indicator.SetUp();

                NTIMcClellanOscillator[] tmp = new NTIMcClellanOscillator[cacheNTIMcClellanOscillator == null ? 1 : cacheNTIMcClellanOscillator.Length + 1];
                if (cacheNTIMcClellanOscillator != null)
                    cacheNTIMcClellanOscillator.CopyTo(tmp, 0);
                tmp[tmp.Length - 1] = indicator;
                cacheNTIMcClellanOscillator = tmp;
                return indicator;
            }
        }
    }
}

// This namespace holds all market analyzer column definitions and is required. Do not change it.
namespace NinjaTrader.MarketAnalyzer
{
    public partial class Column : ColumnBase
    {
        /// <summary>
        /// McMellan Oscillator for advancing and declining stocks
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.NTIMcClellanOscillator NTIMcClellanOscillator(int fastPeriod, int slowPeriod)
        {
            return _indicator.NTIMcClellanOscillator(Input, fastPeriod, slowPeriod);
        }

        /// <summary>
        /// McMellan Oscillator for advancing and declining stocks
        /// </summary>
        /// <returns></returns>
        public Indicator.NTIMcClellanOscillator NTIMcClellanOscillator(Data.IDataSeries input, int fastPeriod, int slowPeriod)
        {
            return _indicator.NTIMcClellanOscillator(input, fastPeriod, slowPeriod);
        }
    }
}

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    public partial class Strategy : StrategyBase
    {
        /// <summary>
        /// McMellan Oscillator for advancing and declining stocks
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.NTIMcClellanOscillator NTIMcClellanOscillator(int fastPeriod, int slowPeriod)
        {
            return _indicator.NTIMcClellanOscillator(Input, fastPeriod, slowPeriod);
        }

        /// <summary>
        /// McMellan Oscillator for advancing and declining stocks
        /// </summary>
        /// <returns></returns>
        public Indicator.NTIMcClellanOscillator NTIMcClellanOscillator(Data.IDataSeries input, int fastPeriod, int slowPeriod)
        {
            if (InInitialize && input == null)
                throw new ArgumentException("You only can access an indicator with the default input/bar series from within the 'Initialize()' method");

            return _indicator.NTIMcClellanOscillator(input, fastPeriod, slowPeriod);
        }
    }
}
#endregion
