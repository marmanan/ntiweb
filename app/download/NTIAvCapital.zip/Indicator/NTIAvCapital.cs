#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
#endregion

// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    /// <summary>
    /// Average proportional capital
    /// </summary>
    [Description("Average proportional capital")]
    public class NTIAvCapital : Indicator
    {
        #region Variables
        // Wizard generated variables
            private int period = 52; // Default setting for Period
			DataSeries apc;
			DataSeries vol;
        // User defined variables (add any user defined variables below)
        #endregion

        /// <summary>
        /// This method is used to configure the indicator and is called once before any bar data is loaded.
        /// </summary>
        protected override void Initialize()
        {
            Add(new Plot(new Pen(Color.FromKnownColor(KnownColor.Green),6), PlotStyle.Bar, "CPM"));
			Add(new Plot(new Pen(Color.FromKnownColor(KnownColor.Red),6), PlotStyle.Bar, "CPMDown"));
			Add(new Line(Color.Gray, 0, "Zero"));
			apc = new DataSeries(this);
			vol = new DataSeries(this);
            Overlay				= false;
        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
            // Use this method for calculating your indicator values. Assign a value to each
            // plot below by replacing 'Close[0]' with your own formula.
			apc.Set(Close[0]*Volume[0]);
			double maxVolume = MAX(apc,period)[0];
			vol.Set((apc[0]*100/maxVolume)*4/5);
			double avPropVolume = WMA(vol,period)[0];
			double value = vol[0]-avPropVolume;
			
			if (value > 0)
			{
			    CPM.Set(value);
				CPMDown.Set(0);
			}
			else
			{
			    CPM.Set(0);
				CPMDown.Set(value);
			}
        }

        #region Properties
        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries CPM
        {
            get { return Values[0]; }
        }

		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries CPMDown
        {
            get { return Values[1]; }
        }
		
        [Description("Period")]
        [GridCategory("Parameters")]
        public int Period
        {
            get { return period; }
            set { period = Math.Max(1, value); }
        }
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.
// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    public partial class Indicator : IndicatorBase
    {
        private NTIAvCapital[] cacheNTIAvCapital = null;

        private static NTIAvCapital checkNTIAvCapital = new NTIAvCapital();

        /// <summary>
        /// Average proportional capital
        /// </summary>
        /// <returns></returns>
        public NTIAvCapital NTIAvCapital(int period)
        {
            return NTIAvCapital(Input, period);
        }

        /// <summary>
        /// Average proportional capital
        /// </summary>
        /// <returns></returns>
        public NTIAvCapital NTIAvCapital(Data.IDataSeries input, int period)
        {
            if (cacheNTIAvCapital != null)
                for (int idx = 0; idx < cacheNTIAvCapital.Length; idx++)
                    if (cacheNTIAvCapital[idx].Period == period && cacheNTIAvCapital[idx].EqualsInput(input))
                        return cacheNTIAvCapital[idx];

            lock (checkNTIAvCapital)
            {
                checkNTIAvCapital.Period = period;
                period = checkNTIAvCapital.Period;

                if (cacheNTIAvCapital != null)
                    for (int idx = 0; idx < cacheNTIAvCapital.Length; idx++)
                        if (cacheNTIAvCapital[idx].Period == period && cacheNTIAvCapital[idx].EqualsInput(input))
                            return cacheNTIAvCapital[idx];

                NTIAvCapital indicator = new NTIAvCapital();
                indicator.BarsRequired = BarsRequired;
                indicator.CalculateOnBarClose = CalculateOnBarClose;
#if NT7
                indicator.ForceMaximumBarsLookBack256 = ForceMaximumBarsLookBack256;
                indicator.MaximumBarsLookBack = MaximumBarsLookBack;
#endif
                indicator.Input = input;
                indicator.Period = period;
                Indicators.Add(indicator);
                indicator.SetUp();

                NTIAvCapital[] tmp = new NTIAvCapital[cacheNTIAvCapital == null ? 1 : cacheNTIAvCapital.Length + 1];
                if (cacheNTIAvCapital != null)
                    cacheNTIAvCapital.CopyTo(tmp, 0);
                tmp[tmp.Length - 1] = indicator;
                cacheNTIAvCapital = tmp;
                return indicator;
            }
        }
    }
}

// This namespace holds all market analyzer column definitions and is required. Do not change it.
namespace NinjaTrader.MarketAnalyzer
{
    public partial class Column : ColumnBase
    {
        /// <summary>
        /// Average proportional capital
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.NTIAvCapital NTIAvCapital(int period)
        {
            return _indicator.NTIAvCapital(Input, period);
        }

        /// <summary>
        /// Average proportional capital
        /// </summary>
        /// <returns></returns>
        public Indicator.NTIAvCapital NTIAvCapital(Data.IDataSeries input, int period)
        {
            return _indicator.NTIAvCapital(input, period);
        }
    }
}

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    public partial class Strategy : StrategyBase
    {
        /// <summary>
        /// Average proportional capital
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.NTIAvCapital NTIAvCapital(int period)
        {
            return _indicator.NTIAvCapital(Input, period);
        }

        /// <summary>
        /// Average proportional capital
        /// </summary>
        /// <returns></returns>
        public Indicator.NTIAvCapital NTIAvCapital(Data.IDataSeries input, int period)
        {
            if (InInitialize && input == null)
                throw new ArgumentException("You only can access an indicator with the default input/bar series from within the 'Initialize()' method");

            return _indicator.NTIAvCapital(input, period);
        }
    }
}
#endregion
