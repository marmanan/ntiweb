#region Using declarations
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
#endregion

// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    /// <summary>
    /// Stochastic Momentum Index
    /// </summary>
    [Description("Stochastic Momentum Index by NT Indicator")]
    public class NTISMI : Indicator
   {
        #region Variables
        // Wizard generated variables
            private int q = 13; // Default setting for Q
            private int r = 25; // Default setting for R
            private int s = 2; // Default setting for S
            private int avgPeriod = 3; // Default setting for AvgPeriod
        // User defined variables (add any user defined variables below)
		
			private DataSeries rdiff;
			private DataSeries diff;
		
        #endregion

        /// <summary>
        /// This method is used to configure the indicator and is called once before any bar data is loaded.
        /// </summary>
        protected override void Initialize()
        {
            Add(new Plot(Color.FromKnownColor(KnownColor.Green), PlotStyle.Line, "SMI"));
            Add(new Plot(Color.FromKnownColor(KnownColor.Red), PlotStyle.Line, "Avg"));
			
			Add(new Line(Color.Gray, -40, "Lower"));
			Add(new Line(Color.Gray, 40, "Upper"));
			
			rdiff = new DataSeries(this);
			diff = new DataSeries(this);

			
            Overlay				= false;
        }

        /// <summary>
        /// Called on each bar update event (incoming tick)
        /// </summary>
        protected override void OnBarUpdate()
        {
			double min_low = MIN(Low, q)[0];
			double max_high = MAX(High, q)[0];
			
			rdiff.Set(Close[0] - (max_high + min_low)/2);
			diff.Set(max_high - min_low);
			
			double avgrel = EMA(EMA(rdiff, r), s)[0];
			double avgdiff = EMA(EMA(diff, r), s)[0];

			
			SMI.Set(avgrel/(avgdiff/2)*100);
            Avg.Set(EMA(SMI, avgPeriod)[0]);
        }

        #region Properties
        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries SMI
        {
            get { return Values[0]; }
        }

        [Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
        [XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
        public DataSeries Avg
        {
            get { return Values[1]; }
        }

        [Description("Q")]
        [GridCategory("Parameters")]
        public int Q
        {
            get { return q; }
            set { q = Math.Max(1, value); }
        }

        [Description("R")]
        [GridCategory("Parameters")]
        public int R
        {
            get { return r; }
            set { r = Math.Max(1, value); }
        }

        [Description("S")]
        [GridCategory("Parameters")]
        public int S
        {
            get { return s; }
            set { s = Math.Max(1, value); }
        }

        [Description("Average Period")]
        [GridCategory("Parameters")]
        public int AvgPeriod
        {
            get { return avgPeriod; }
            set { avgPeriod = Math.Max(1, value); }
        }
        #endregion
    }
}

#region NinjaScript generated code. Neither change nor remove.
// This namespace holds all indicators and is required. Do not change it.
namespace NinjaTrader.Indicator
{
    public partial class Indicator : IndicatorBase
    {
        private NTISMI[] cacheNTISMI = null;

        private static NTISMI checkNTISMI = new NTISMI();

        /// <summary>
        /// Stochastic Momentum Index by NT Indicator
        /// </summary>
        /// <returns></returns>
        public NTISMI NTISMI(int avgPeriod, int q, int r, int s)
        {
            return NTISMI(Input, avgPeriod, q, r, s);
        }

        /// <summary>
        /// Stochastic Momentum Index by NT Indicator
        /// </summary>
        /// <returns></returns>
        public NTISMI NTISMI(Data.IDataSeries input, int avgPeriod, int q, int r, int s)
        {
            if (cacheNTISMI != null)
                for (int idx = 0; idx < cacheNTISMI.Length; idx++)
                    if (cacheNTISMI[idx].AvgPeriod == avgPeriod && cacheNTISMI[idx].Q == q && cacheNTISMI[idx].R == r && cacheNTISMI[idx].S == s && cacheNTISMI[idx].EqualsInput(input))
                        return cacheNTISMI[idx];

            lock (checkNTISMI)
            {
                checkNTISMI.AvgPeriod = avgPeriod;
                avgPeriod = checkNTISMI.AvgPeriod;
                checkNTISMI.Q = q;
                q = checkNTISMI.Q;
                checkNTISMI.R = r;
                r = checkNTISMI.R;
                checkNTISMI.S = s;
                s = checkNTISMI.S;

                if (cacheNTISMI != null)
                    for (int idx = 0; idx < cacheNTISMI.Length; idx++)
                        if (cacheNTISMI[idx].AvgPeriod == avgPeriod && cacheNTISMI[idx].Q == q && cacheNTISMI[idx].R == r && cacheNTISMI[idx].S == s && cacheNTISMI[idx].EqualsInput(input))
                            return cacheNTISMI[idx];

                NTISMI indicator = new NTISMI();
                indicator.BarsRequired = BarsRequired;
                indicator.CalculateOnBarClose = CalculateOnBarClose;
#if NT7
                indicator.ForceMaximumBarsLookBack256 = ForceMaximumBarsLookBack256;
                indicator.MaximumBarsLookBack = MaximumBarsLookBack;
#endif
                indicator.Input = input;
                indicator.AvgPeriod = avgPeriod;
                indicator.Q = q;
                indicator.R = r;
                indicator.S = s;
                Indicators.Add(indicator);
                indicator.SetUp();

                NTISMI[] tmp = new NTISMI[cacheNTISMI == null ? 1 : cacheNTISMI.Length + 1];
                if (cacheNTISMI != null)
                    cacheNTISMI.CopyTo(tmp, 0);
                tmp[tmp.Length - 1] = indicator;
                cacheNTISMI = tmp;
                return indicator;
            }
        }
    }
}

// This namespace holds all market analyzer column definitions and is required. Do not change it.
namespace NinjaTrader.MarketAnalyzer
{
    public partial class Column : ColumnBase
    {
        /// <summary>
        /// Stochastic Momentum Index by NT Indicator
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.NTISMI NTISMI(int avgPeriod, int q, int r, int s)
        {
            return _indicator.NTISMI(Input, avgPeriod, q, r, s);
        }

        /// <summary>
        /// Stochastic Momentum Index by NT Indicator
        /// </summary>
        /// <returns></returns>
        public Indicator.NTISMI NTISMI(Data.IDataSeries input, int avgPeriod, int q, int r, int s)
        {
            return _indicator.NTISMI(input, avgPeriod, q, r, s);
        }
    }
}

// This namespace holds all strategies and is required. Do not change it.
namespace NinjaTrader.Strategy
{
    public partial class Strategy : StrategyBase
    {
        /// <summary>
        /// Stochastic Momentum Index by NT Indicator
        /// </summary>
        /// <returns></returns>
        [Gui.Design.WizardCondition("Indicator")]
        public Indicator.NTISMI NTISMI(int avgPeriod, int q, int r, int s)
        {
            return _indicator.NTISMI(Input, avgPeriod, q, r, s);
        }

        /// <summary>
        /// Stochastic Momentum Index by NT Indicator
        /// </summary>
        /// <returns></returns>
        public Indicator.NTISMI NTISMI(Data.IDataSeries input, int avgPeriod, int q, int r, int s)
        {
            if (InInitialize && input == null)
                throw new ArgumentException("You only can access an indicator with the default input/bar series from within the 'Initialize()' method");

            return _indicator.NTISMI(input, avgPeriod, q, r, s);
        }
    }
}
#endregion
